package servico;

public class FreteCalculadoraDistancia {
    public double calcular(double distanciaKm) {
        return distanciaKm * 0.50;
    }
}